USER INTERFACE

This visualization is web-based and runs on a HTML web page using JavaScript. All of the libraries used are imported via URL links to files hosted on the internet, so
no additional software download is necessary. In order to run the visualization on your local computer, download the source code from the GitHub repository and launch the HTML file with a python server. The data presented is collected from Numbeo.com, and the formatted TSV file is included in the repository.
 
CODE DOCUMENTATION

This program can be modified to visualize other data sets with country level granularity. Detailed user documentation is embedded in the code (script.js) as comments.
